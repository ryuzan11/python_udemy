from lesson_package.tools import utils

def sing():
  return 'aaaaa'

def cry():
  return utils.say_twice('bbbbb')